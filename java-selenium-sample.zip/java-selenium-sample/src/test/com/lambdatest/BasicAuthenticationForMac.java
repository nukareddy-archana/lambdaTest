package com.lambdatest;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.HasAuthentication;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.UsernameAndPassword;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.HasDevTools;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class BasicAuthenticationForMac {
	public static String hubURL = "https://hub.lambdatest.com/wd/hub";
	private WebDriver driver;

	@BeforeMethod
	public void setup() throws MalformedURLException {

		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("browserName", "Microsoft Edge");
		capabilities.setCapability("browserVersion", "87.0");
		HashMap<String, Object> ltOptions = new HashMap<String, Object>();
		ltOptions.put("user", "narchana");
		ltOptions.put("accessKey", "7RWfIY1ExBvILuCnn5jGJix6Yyr7epJIXLGtVLLY3vrTKPdpdZ");
		ltOptions.put("build", "LambdaTest");
		ltOptions.put("name", this.getClass().getName());
		ltOptions.put("platformName", "macos Sierra");
		ltOptions.put("seCdp", true);
		ltOptions.put("selenium_version", "4.0.0");
		capabilities.setCapability("LT:Options", ltOptions);

		driver = new RemoteWebDriver(new URL(hubURL), capabilities);
		System.out.println(driver);
	}

	@Test
	public void executeLambdaTest() {
		// Scenario1
		Augmenter augmenter = new Augmenter();
		driver = augmenter.augment(driver);
		driver.get("https://www.lambdatest.com");
		// scenario 2
		WebDriverWait wait = new WebDriverWait(driver, 2);
		WebElement element_to_scroll_to = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.linkText("SEE ALL INTEGRATIONS")));

		// scenario 3
		element_to_scroll_to.sendKeys(Keys.chord(Keys.COMMAND, Keys.RETURN));
		for (String handle : driver.getWindowHandles()) {
			System.out.println("Mac Handle: " + handle);
			driver.switchTo().window(driver.getWindowHandles().toArray()[0].toString());
		}
		System.out.println("currentURl : " + driver.getCurrentUrl());
		String epected_url = "https://www.lambdatest.com/";
		Assert.assertEquals(driver.getCurrentUrl(), epected_url, "URLs do not match.");
		driver.quit();

	}

	public void authentication() {
		Augmenter augmenter = new Augmenter();
		driver = augmenter.augment(driver);

		DevTools devTools = ((HasDevTools) driver).getDevTools();
		devTools.createSession();

		driver = augmenter.addDriverAugmentation("chrome", HasAuthentication.class,
				(caps, exec) -> (whenThisMatches, useTheseCredentials) -> devTools.getDomains().network()
						.addAuthHandler(whenThisMatches, useTheseCredentials))
				.augment(driver);

		((HasAuthentication) driver).register(UsernameAndPassword.of("foo", "bar"));

		driver.get("http://httpbin.org/basic-auth/foo/bar");

		String text = driver.findElement(By.tagName("body")).getText();
		System.out.println(text);
		if (text.contains("authenticated")) {
			markStatus("passed", "Authentication Successful", driver);
		} else {
			markStatus("failed", "Authentication Failure", driver);
		}

	}

	public void tearDown() {
		try {
			driver.quit();
		} catch (

		Exception e) {
			markStatus("failed", "Got exception!", driver);
			e.printStackTrace();
			driver.quit();
		}
	}

	public static void markStatus(String status, String reason, WebDriver driver) {
		JavascriptExecutor jsExecute = (JavascriptExecutor) driver;
		jsExecute.executeScript("lambda-status=" + status);
		System.out.println(reason);
	}

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		BasicAuthenticationForMac test = new BasicAuthenticationForMac();
		test.setup();
		test.authentication();
		test.tearDown();
	}
}
